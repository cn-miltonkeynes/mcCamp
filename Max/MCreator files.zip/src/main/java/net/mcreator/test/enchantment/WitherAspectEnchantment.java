
package net.mcreator.test.enchantment;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.util.DamageSource;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.enchantment.EnchantmentType;
import net.minecraft.enchantment.Enchantment;

import net.mcreator.test.TestModElements;

@TestModElements.ModElement.Tag
public class WitherAspectEnchantment extends TestModElements.ModElement {
	@ObjectHolder("test:wither_aspect")
	public static final Enchantment enchantment = null;
	public WitherAspectEnchantment(TestModElements instance) {
		super(instance, 22);
	}

	@Override
	public void initElements() {
		elements.enchantments.add(() -> new CustomEnchantment(EquipmentSlotType.MAINHAND).setRegistryName("wither_aspect"));
	}
	public static class CustomEnchantment extends Enchantment {
		public CustomEnchantment(EquipmentSlotType... slots) {
			super(Enchantment.Rarity.VERY_RARE, EnchantmentType.WEAPON, slots);
		}

		@Override
		public int getMinLevel() {
			return 50;
		}

		@Override
		public int getMaxLevel() {
			return 1000;
		}

		@Override
		public int calcModifierDamage(int level, DamageSource source) {
			return level * 500;
		}

		@Override
		public boolean isTreasureEnchantment() {
			return false;
		}

		@Override
		public boolean isCurse() {
			return false;
		}

		@Override
		public boolean isAllowedOnBooks() {
			return false;
		}

		@Override
		public boolean canGenerateInLoot() {
			return false;
		}

		@Override
		public boolean canVillagerTrade() {
			return false;
		}
	}
}
