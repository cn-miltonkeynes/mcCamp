
package net.mcreator.test.potion;

import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.potion.Potion;
import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BeserkerPotionPotion {
	@ObjectHolder("test:beserker_potion")
	public static final Potion potionType = null;
	@SubscribeEvent
	public static void registerPotion(RegistryEvent.Register<Potion> event) {
		event.getRegistry().register(new PotionCustom());
	}
	public static class PotionCustom extends Potion {
		public PotionCustom() {
			super(new EffectInstance(Effects.STRENGTH, 600, 10, false, true), new EffectInstance(Effects.POISON, 600, 50, false, true),
					new EffectInstance(Effects.SPEED, 600, 3, false, true));
			setRegistryName("beserker_potion");
		}
	}
}
