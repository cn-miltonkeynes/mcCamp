// Made with Blockbench 4.3.1
// Exported for Minecraft version 1.15 - 1.16 with Mojang mappings
// Paste this class into your mod and generate all required imports

public static class ModelChild extends EntityModel<Entity> {
	private final ModelRenderer Head;
	private final ModelRenderer body;
	private final ModelRenderer larm;
	private final ModelRenderer rarm;
	private final ModelRenderer lleg;
	private final ModelRenderer rleg;

	public ModelChild() {
		texWidth = 64;
		texHeight = 64;

		Head = new ModelRenderer(this);
		Head.setPos(0.0F, 12.0F, 0.0F);
		Head.texOffs(18, 19).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F, 0.0F, false);

		body = new ModelRenderer(this);
		body.setPos(0.0F, 24.0F, 0.0F);
		body.texOffs(0, 10).addBox(-4.0F, -12.0F, -2.0F, 8.0F, 11.0F, 4.0F, 0.0F, false);

		larm = new ModelRenderer(this);
		larm.setPos(4.0F, 13.0F, 0.0F);
		larm.texOffs(30, 31).addBox(0.0F, -1.0F, -2.0F, 3.0F, 11.0F, 4.0F, 0.0F, false);

		rarm = new ModelRenderer(this);
		rarm.setPos(-4.0F, 13.0F, 0.0F);
		rarm.texOffs(16, 31).addBox(-3.0F, -1.0F, -2.0F, 3.0F, 11.0F, 4.0F, 0.0F, false);

		lleg = new ModelRenderer(this);
		lleg.setPos(-2.0F, 23.0F, 0.0F);
		lleg.texOffs(30, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 11.0F, 4.0F, 0.0F, false);

		rleg = new ModelRenderer(this);
		rleg.setPos(2.0F, 23.0F, 0.0F);
		rleg.texOffs(0, 25).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 11.0F, 4.0F, 0.0F, false);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
		// previously the render function, render code was moved to a method below
	}

	@Override
	public void renderToBuffer(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		Head.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		body.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		larm.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		rarm.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		lleg.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		rleg.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.xRot = x;
		modelRenderer.yRot = y;
		modelRenderer.zRot = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, e);
		this.lleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
		this.Head.rotateAngleY = f3 / (180F / (float) Math.PI);
		this.Head.rotateAngleX = f4 / (180F / (float) Math.PI);
		this.larm.rotateAngleX = MathHelper.cos(f * 0.6662F) * f1;
		this.rleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
		this.rarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float) Math.PI) * f1;
	}
}