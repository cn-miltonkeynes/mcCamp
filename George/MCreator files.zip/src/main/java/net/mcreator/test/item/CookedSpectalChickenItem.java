
package net.mcreator.test.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.UseAction;
import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.Food;

import net.mcreator.test.itemgroup.LostFoodItemGroup;
import net.mcreator.test.TestModElements;

@TestModElements.ModElement.Tag
public class CookedSpectalChickenItem extends TestModElements.ModElement {
	@ObjectHolder("test:cooked_spectal_chicken")
	public static final Item block = null;
	public CookedSpectalChickenItem(TestModElements instance) {
		super(instance, 9);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new FoodItemCustom());
	}
	public static class FoodItemCustom extends Item {
		public FoodItemCustom() {
			super(new Item.Properties().group(LostFoodItemGroup.tab).maxStackSize(64).rarity(Rarity.EPIC)
					.food((new Food.Builder()).hunger(13).saturation(2.9f).meat().build()));
			setRegistryName("cooked_spectal_chicken");
		}

		@Override
		public UseAction getUseAction(ItemStack itemstack) {
			return UseAction.EAT;
		}
	}
}
