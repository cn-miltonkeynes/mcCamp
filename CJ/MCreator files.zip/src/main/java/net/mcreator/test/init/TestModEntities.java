
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.test.entity.ThepuppetEntity;
import net.mcreator.test.entity.SheeshersEntity;
import net.mcreator.test.entity.GunEntity;
import net.mcreator.test.entity.FlyingboiEntity;
import net.mcreator.test.TestMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TestModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, TestMod.MODID);
	public static final RegistryObject<EntityType<SheeshersEntity>> SHEESHERS = register("sheeshers",
			EntityType.Builder.<SheeshersEntity>of(SheeshersEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SheeshersEntity::new).fireImmune().sized(0.4f, 0.3f));
	public static final RegistryObject<EntityType<FlyingboiEntity>> FLYINGBOI = register("flyingboi",
			EntityType.Builder.<FlyingboiEntity>of(FlyingboiEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FlyingboiEntity::new)

					.sized(1f, 1f));
	public static final RegistryObject<EntityType<ThepuppetEntity>> THEPUPPET = register("thepuppet",
			EntityType.Builder.<ThepuppetEntity>of(ThepuppetEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ThepuppetEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<GunEntity>> GUN = register("projectile_gun",
			EntityType.Builder.<GunEntity>of(GunEntity::new, MobCategory.MISC).setCustomClientFactory(GunEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SheeshersEntity.init();
			FlyingboiEntity.init();
			ThepuppetEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SHEESHERS.get(), SheeshersEntity.createAttributes().build());
		event.put(FLYINGBOI.get(), FlyingboiEntity.createAttributes().build());
		event.put(THEPUPPET.get(), ThepuppetEntity.createAttributes().build());
	}
}
