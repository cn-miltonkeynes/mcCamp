
package net.mcreator.test.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.test.entity.ThepuppetEntity;

public class ThepuppetRenderer extends HumanoidMobRenderer<ThepuppetEntity, HumanoidModel<ThepuppetEntity>> {
	public ThepuppetRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
				new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR))));
	}

	@Override
	public ResourceLocation getTextureLocation(ThepuppetEntity entity) {
		return new ResourceLocation(
				"test:textures/lgzqabqfj4awlgnatfpsyghmwiaplwe4axo8pabh9ttgeeg3yvafjamj3cx4sgizirqh8b1s32wjp6qojaaaaaelftksuqmcc.png");
	}
}
