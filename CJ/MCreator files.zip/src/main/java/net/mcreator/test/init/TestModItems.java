
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.test.item.SussyfoodItem;
import net.mcreator.test.item.SheeshswordItem;
import net.mcreator.test.item.SheeshondItem;
import net.mcreator.test.item.SheeshdimensionItem;
import net.mcreator.test.item.SheesharmorItem;
import net.mcreator.test.item.Mulah100pItem;
import net.mcreator.test.item.GunItem;
import net.mcreator.test.item.DreamItem;
import net.mcreator.test.TestMod;

public class TestModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TestMod.MODID);
	public static final RegistryObject<Item> SHEESHORE = block(TestModBlocks.SHEESHORE, TestModTabs.TAB_SHEESHS);
	public static final RegistryObject<Item> SHEESHOND = REGISTRY.register("sheeshond", () -> new SheeshondItem());
	public static final RegistryObject<Item> SHEESHSWORD = REGISTRY.register("sheeshsword", () -> new SheeshswordItem());
	public static final RegistryObject<Item> SHEESHERS = REGISTRY.register("sheeshers_spawn_egg",
			() -> new ForgeSpawnEggItem(TestModEntities.SHEESHERS, -26368, -3381760, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SHEESHARMOR_HELMET = REGISTRY.register("sheesharmor_helmet", () -> new SheesharmorItem.Helmet());
	public static final RegistryObject<Item> SHEESHARMOR_CHESTPLATE = REGISTRY.register("sheesharmor_chestplate",
			() -> new SheesharmorItem.Chestplate());
	public static final RegistryObject<Item> SHEESHARMOR_LEGGINGS = REGISTRY.register("sheesharmor_leggings", () -> new SheesharmorItem.Leggings());
	public static final RegistryObject<Item> SHEESHARMOR_BOOTS = REGISTRY.register("sheesharmor_boots", () -> new SheesharmorItem.Boots());
	public static final RegistryObject<Item> SHEESHDIMENSION = REGISTRY.register("sheeshdimension", () -> new SheeshdimensionItem());
	public static final RegistryObject<Item> SUSSYFOOD = REGISTRY.register("sussyfood", () -> new SussyfoodItem());
	public static final RegistryObject<Item> DREAM_HELMET = REGISTRY.register("dream_helmet", () -> new DreamItem.Helmet());
	public static final RegistryObject<Item> DREAM_CHESTPLATE = REGISTRY.register("dream_chestplate", () -> new DreamItem.Chestplate());
	public static final RegistryObject<Item> DREAM_LEGGINGS = REGISTRY.register("dream_leggings", () -> new DreamItem.Leggings());
	public static final RegistryObject<Item> DREAM_BOOTS = REGISTRY.register("dream_boots", () -> new DreamItem.Boots());
	public static final RegistryObject<Item> MULAH_100P = REGISTRY.register("mulah_100p", () -> new Mulah100pItem());
	public static final RegistryObject<Item> FLYINGBOI = REGISTRY.register("flyingboi_spawn_egg",
			() -> new ForgeSpawnEggItem(TestModEntities.FLYINGBOI, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SHEESHWOOD = block(TestModBlocks.SHEESHWOOD, TestModTabs.TAB_SHEESHS);
	public static final RegistryObject<Item> THEPUPPET = REGISTRY.register("thepuppet_spawn_egg",
			() -> new ForgeSpawnEggItem(TestModEntities.THEPUPPET, -39424, -10027264, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> GUN = REGISTRY.register("gun", () -> new GunItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
