
package net.mcreator.robbie.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.fluids.FluidAttributes;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.robbie.init.RobbieModItems;
import net.mcreator.robbie.init.RobbieModFluids;
import net.mcreator.robbie.init.RobbieModBlocks;

public abstract class Texture1Fluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(RobbieModFluids.TEXTURE_1,
			RobbieModFluids.FLOWING_TEXTURE_1,
			FluidAttributes.builder(new ResourceLocation("robbie:blocks/texture_1"), new ResourceLocation("robbie:blocks/texture_1"))

					.gaseous()

	).explosionResistance(107f)

			.bucket(RobbieModItems.TEXTURE_1_BUCKET).block(() -> (LiquidBlock) RobbieModBlocks.TEXTURE_1.get());

	private Texture1Fluid() {
		super(PROPERTIES);
	}

	public static class Source extends Texture1Fluid {
		public Source() {
			super();
		}

		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends Texture1Fluid {
		public Flowing() {
			super();
		}

		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
