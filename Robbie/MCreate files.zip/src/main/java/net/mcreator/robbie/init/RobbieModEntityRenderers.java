
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robbie.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.robbie.client.renderer.SnasurRenderer;
import net.mcreator.robbie.client.renderer.SmabyRenderer;
import net.mcreator.robbie.client.renderer.RobbieRenderer;
import net.mcreator.robbie.client.renderer.DeeznutscreRenderer;
import net.mcreator.robbie.client.renderer.BurtRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RobbieModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(RobbieModEntities.SNASUR.get(), SnasurRenderer::new);
		event.registerEntityRenderer(RobbieModEntities.ROBBIE.get(), RobbieRenderer::new);
		event.registerEntityRenderer(RobbieModEntities.BURT.get(), BurtRenderer::new);
		event.registerEntityRenderer(RobbieModEntities.SMABY.get(), SmabyRenderer::new);
		event.registerEntityRenderer(RobbieModEntities.DEEZNUTSCRE.get(), DeeznutscreRenderer::new);
		event.registerEntityRenderer(RobbieModEntities.GUN.get(), ThrownItemRenderer::new);
	}
}
