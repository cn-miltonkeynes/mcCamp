
package net.mcreator.robbie.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

import net.mcreator.robbie.init.RobbieModTabs;

public class RawpoopItem extends Item {
	public RawpoopItem() {
		super(new Item.Properties().tab(RobbieModTabs.TAB_BOBS).stacksTo(64).rarity(Rarity.COMMON)
				.food((new FoodProperties.Builder()).nutrition(420).saturationMod(0.3f).alwaysEat().meat().build()));
	}

	@Override
	public int getEnchantmentValue() {
		return 8;
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 32;
	}
}
