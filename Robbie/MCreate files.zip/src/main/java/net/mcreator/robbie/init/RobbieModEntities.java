
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robbie.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.robbie.entity.SnasurEntity;
import net.mcreator.robbie.entity.SmabyEntity;
import net.mcreator.robbie.entity.RobbieEntity;
import net.mcreator.robbie.entity.GunEntity;
import net.mcreator.robbie.entity.DeeznutscreEntity;
import net.mcreator.robbie.entity.BurtEntity;
import net.mcreator.robbie.RobbieMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RobbieModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, RobbieMod.MODID);
	public static final RegistryObject<EntityType<SnasurEntity>> SNASUR = register("snasur",
			EntityType.Builder.<SnasurEntity>of(SnasurEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(SnasurEntity::new).fireImmune().sized(1.4f, 0.9f));
	public static final RegistryObject<EntityType<RobbieEntity>> ROBBIE = register("robbie",
			EntityType.Builder.<RobbieEntity>of(RobbieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(RobbieEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<BurtEntity>> BURT = register("burt",
			EntityType.Builder.<BurtEntity>of(BurtEntity::new, MobCategory.AXOLOTLS).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(BurtEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<SmabyEntity>> SMABY = register("smaby",
			EntityType.Builder.<SmabyEntity>of(SmabyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(SmabyEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<DeeznutscreEntity>> DEEZNUTSCRE = register("deeznutscre",
			EntityType.Builder.<DeeznutscreEntity>of(DeeznutscreEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DeeznutscreEntity::new)

					.sized(0.6f, 1.7f));
	public static final RegistryObject<EntityType<GunEntity>> GUN = register("projectile_gun",
			EntityType.Builder.<GunEntity>of(GunEntity::new, MobCategory.MISC).setCustomClientFactory(GunEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SnasurEntity.init();
			RobbieEntity.init();
			BurtEntity.init();
			SmabyEntity.init();
			DeeznutscreEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SNASUR.get(), SnasurEntity.createAttributes().build());
		event.put(ROBBIE.get(), RobbieEntity.createAttributes().build());
		event.put(BURT.get(), BurtEntity.createAttributes().build());
		event.put(SMABY.get(), SmabyEntity.createAttributes().build());
		event.put(DEEZNUTSCRE.get(), DeeznutscreEntity.createAttributes().build());
	}
}
