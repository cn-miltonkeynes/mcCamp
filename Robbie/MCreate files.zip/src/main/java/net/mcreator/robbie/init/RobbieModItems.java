
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robbie.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.robbie.item.Texture1Item;
import net.mcreator.robbie.item.TeItem;
import net.mcreator.robbie.item.RawpoopItem;
import net.mcreator.robbie.item.PoopinabucketItem;
import net.mcreator.robbie.item.GunItem;
import net.mcreator.robbie.item.BobspickaxItem;
import net.mcreator.robbie.item.BobsknifeItem;
import net.mcreator.robbie.item.BobsdimetionItem;
import net.mcreator.robbie.item.BobsarmorItem;
import net.mcreator.robbie.item.BobingotItem;
import net.mcreator.robbie.item.BloodofchildrenItem;
import net.mcreator.robbie.item.AmmoItem;
import net.mcreator.robbie.RobbieMod;

public class RobbieModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, RobbieMod.MODID);
	public static final RegistryObject<Item> BOB_ORE = block(RobbieModBlocks.BOB_ORE, RobbieModTabs.TAB_BOBS);
	public static final RegistryObject<Item> BOBSARMOR_HELMET = REGISTRY.register("bobsarmor_helmet", () -> new BobsarmorItem.Helmet());
	public static final RegistryObject<Item> BOBSARMOR_CHESTPLATE = REGISTRY.register("bobsarmor_chestplate", () -> new BobsarmorItem.Chestplate());
	public static final RegistryObject<Item> BOBSARMOR_LEGGINGS = REGISTRY.register("bobsarmor_leggings", () -> new BobsarmorItem.Leggings());
	public static final RegistryObject<Item> BOBSARMOR_BOOTS = REGISTRY.register("bobsarmor_boots", () -> new BobsarmorItem.Boots());
	public static final RegistryObject<Item> BOBINGOT = REGISTRY.register("bobingot", () -> new BobingotItem());
	public static final RegistryObject<Item> BOBSKNIFE = REGISTRY.register("bobsknife", () -> new BobsknifeItem());
	public static final RegistryObject<Item> RAWPOOP = REGISTRY.register("rawpoop", () -> new RawpoopItem());
	public static final RegistryObject<Item> POOPINABUCKET = REGISTRY.register("poopinabucket", () -> new PoopinabucketItem());
	public static final RegistryObject<Item> BEDROCKSURFACED = block(RobbieModBlocks.BEDROCKSURFACED, RobbieModTabs.TAB_BOBS);
	public static final RegistryObject<Item> DEEZNUTS = block(RobbieModBlocks.DEEZNUTS, RobbieModTabs.TAB_BOBS);
	public static final RegistryObject<Item> BLOODOFCHILDREN_BUCKET = REGISTRY.register("bloodofchildren_bucket", () -> new BloodofchildrenItem());
	public static final RegistryObject<Item> BOBSDIMETION = REGISTRY.register("bobsdimetion", () -> new BobsdimetionItem());
	public static final RegistryObject<Item> SNASUR = REGISTRY.register("snasur_spawn_egg",
			() -> new ForgeSpawnEggItem(RobbieModEntities.SNASUR, -1, -1, new Item.Properties().tab(RobbieModTabs.TAB_BOBS)));
	public static final RegistryObject<Item> TE_BUCKET = REGISTRY.register("te_bucket", () -> new TeItem());
	public static final RegistryObject<Item> ROBBIE = REGISTRY.register("robbie_spawn_egg",
			() -> new ForgeSpawnEggItem(RobbieModEntities.ROBBIE, -1, -1, new Item.Properties().tab(RobbieModTabs.TAB_BOBS)));
	public static final RegistryObject<Item> BURT = REGISTRY.register("burt_spawn_egg",
			() -> new ForgeSpawnEggItem(RobbieModEntities.BURT, -1, -1, new Item.Properties().tab(RobbieModTabs.TAB_BOBS)));
	public static final RegistryObject<Item> TEXTURE_1_BUCKET = REGISTRY.register("texture_1_bucket", () -> new Texture1Item());
	public static final RegistryObject<Item> SMABY = REGISTRY.register("smaby_spawn_egg",
			() -> new ForgeSpawnEggItem(RobbieModEntities.SMABY, -1, -1, new Item.Properties().tab(RobbieModTabs.TAB_BOBS)));
	public static final RegistryObject<Item> DEEZNUTSCRE = REGISTRY.register("deeznutscre_spawn_egg",
			() -> new ForgeSpawnEggItem(RobbieModEntities.DEEZNUTSCRE, -16737895, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> AMMO = REGISTRY.register("ammo", () -> new AmmoItem());
	public static final RegistryObject<Item> GUN = REGISTRY.register("gun", () -> new GunItem());
	public static final RegistryObject<Item> ICEDLAVA = block(RobbieModBlocks.ICEDLAVA, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> FIREWOOD = block(RobbieModBlocks.FIREWOOD, RobbieModTabs.TAB_BOBS);
	public static final RegistryObject<Item> BOBSPICKAX = REGISTRY.register("bobspickax", () -> new BobspickaxItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
