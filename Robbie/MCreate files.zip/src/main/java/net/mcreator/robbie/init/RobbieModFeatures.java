
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robbie.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;

import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Holder;

import net.mcreator.robbie.world.features.plants.DeeznutsFeature;
import net.mcreator.robbie.world.features.ores.BedrocksurfacedFeature;
import net.mcreator.robbie.world.features.lakes.Texture1Feature;
import net.mcreator.robbie.world.features.lakes.TeFeature;
import net.mcreator.robbie.world.features.lakes.BloodofchildrenFeature;
import net.mcreator.robbie.world.features.ThebunkerFeature;
import net.mcreator.robbie.RobbieMod;

import java.util.function.Supplier;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber
public class RobbieModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, RobbieMod.MODID);
	private static final List<FeatureRegistration> FEATURE_REGISTRATIONS = new ArrayList<>();
	public static final RegistryObject<Feature<?>> BEDROCKSURFACED = register("bedrocksurfaced", BedrocksurfacedFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, BedrocksurfacedFeature.GENERATE_BIOMES,
					BedrocksurfacedFeature::placedFeature));
	public static final RegistryObject<Feature<?>> DEEZNUTS = register("deeznuts", DeeznutsFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.VEGETAL_DECORATION, DeeznutsFeature.GENERATE_BIOMES, DeeznutsFeature::placedFeature));
	public static final RegistryObject<Feature<?>> BLOODOFCHILDREN = register("bloodofchildren", BloodofchildrenFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.LAKES, BloodofchildrenFeature.GENERATE_BIOMES, BloodofchildrenFeature::placedFeature));
	public static final RegistryObject<Feature<?>> TE = register("te", TeFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.LAKES, TeFeature.GENERATE_BIOMES, TeFeature::placedFeature));
	public static final RegistryObject<Feature<?>> TEXTURE_1 = register("texture_1", Texture1Feature::feature,
			new FeatureRegistration(GenerationStep.Decoration.LAKES, Texture1Feature.GENERATE_BIOMES, Texture1Feature::placedFeature));
	public static final RegistryObject<Feature<?>> THEBUNKER = register("thebunker", ThebunkerFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, ThebunkerFeature.GENERATE_BIOMES, ThebunkerFeature::placedFeature));

	private static RegistryObject<Feature<?>> register(String registryname, Supplier<Feature<?>> feature, FeatureRegistration featureRegistration) {
		FEATURE_REGISTRATIONS.add(featureRegistration);
		return REGISTRY.register(registryname, feature);
	}

	@SubscribeEvent
	public static void addFeaturesToBiomes(BiomeLoadingEvent event) {
		for (FeatureRegistration registration : FEATURE_REGISTRATIONS) {
			if (registration.biomes() == null || registration.biomes().contains(event.getName()))
				event.getGeneration().getFeatures(registration.stage()).add(registration.placedFeature().get());
		}
	}

	private static record FeatureRegistration(GenerationStep.Decoration stage, Set<ResourceLocation> biomes,
			Supplier<Holder<PlacedFeature>> placedFeature) {
	}
}
