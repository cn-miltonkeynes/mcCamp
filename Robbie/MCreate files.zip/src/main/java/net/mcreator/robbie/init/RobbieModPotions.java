
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robbie.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.robbie.RobbieMod;

public class RobbieModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, RobbieMod.MODID);
	public static final RegistryObject<Potion> SODA = REGISTRY.register("soda",
			() -> new Potion(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 3600, 22, true, false),
					new MobEffectInstance(MobEffects.DIG_SPEED, 3600, 22, true, true),
					new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3600, 22, true, true),
					new MobEffectInstance(MobEffects.REGENERATION, 3600, 22, true, true),
					new MobEffectInstance(MobEffects.JUMP, 3600, 22, true, true),
					new MobEffectInstance(MobEffects.WATER_BREATHING, 3600, 22, true, true),
					new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 3600, 22, true, true),
					new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 3600, 22, true, true),
					new MobEffectInstance(MobEffects.BLINDNESS, 3600, 98, false, true)));
}
