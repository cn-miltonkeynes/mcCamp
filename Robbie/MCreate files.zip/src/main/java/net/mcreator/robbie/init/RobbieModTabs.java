
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robbie.init;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class RobbieModTabs {
	public static CreativeModeTab TAB_BOBS;

	public static void load() {
		TAB_BOBS = new CreativeModeTab("tabbobs") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(RobbieModItems.BOBINGOT.get());
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
	}
}
