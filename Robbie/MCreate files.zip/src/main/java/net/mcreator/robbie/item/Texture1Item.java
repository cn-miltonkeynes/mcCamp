
package net.mcreator.robbie.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BucketItem;

import net.mcreator.robbie.init.RobbieModFluids;

public class Texture1Item extends BucketItem {
	public Texture1Item() {
		super(RobbieModFluids.TEXTURE_1,
				new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON).tab(CreativeModeTab.TAB_MISC));
	}
}
