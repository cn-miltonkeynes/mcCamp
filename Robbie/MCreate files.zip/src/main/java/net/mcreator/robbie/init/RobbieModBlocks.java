
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robbie.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ColorHandlerEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.robbie.block.Texture1Block;
import net.mcreator.robbie.block.TeBlock;
import net.mcreator.robbie.block.IcedlavaBlock;
import net.mcreator.robbie.block.FirewoodBlock;
import net.mcreator.robbie.block.DeeznutsBlock;
import net.mcreator.robbie.block.BobsdimetionPortalBlock;
import net.mcreator.robbie.block.BobOreBlock;
import net.mcreator.robbie.block.BloodofchildrenBlock;
import net.mcreator.robbie.block.BedrocksurfacedBlock;
import net.mcreator.robbie.RobbieMod;

public class RobbieModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, RobbieMod.MODID);
	public static final RegistryObject<Block> BOB_ORE = REGISTRY.register("bob_ore", () -> new BobOreBlock());
	public static final RegistryObject<Block> BEDROCKSURFACED = REGISTRY.register("bedrocksurfaced", () -> new BedrocksurfacedBlock());
	public static final RegistryObject<Block> DEEZNUTS = REGISTRY.register("deeznuts", () -> new DeeznutsBlock());
	public static final RegistryObject<Block> BLOODOFCHILDREN = REGISTRY.register("bloodofchildren", () -> new BloodofchildrenBlock());
	public static final RegistryObject<Block> BOBSDIMETION_PORTAL = REGISTRY.register("bobsdimetion_portal", () -> new BobsdimetionPortalBlock());
	public static final RegistryObject<Block> TE = REGISTRY.register("te", () -> new TeBlock());
	public static final RegistryObject<Block> TEXTURE_1 = REGISTRY.register("texture_1", () -> new Texture1Block());
	public static final RegistryObject<Block> ICEDLAVA = REGISTRY.register("icedlava", () -> new IcedlavaBlock());
	public static final RegistryObject<Block> FIREWOOD = REGISTRY.register("firewood", () -> new FirewoodBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			BedrocksurfacedBlock.registerRenderLayer();
			DeeznutsBlock.registerRenderLayer();
		}

		@SubscribeEvent
		public static void blockColorLoad(ColorHandlerEvent.Block event) {
			BedrocksurfacedBlock.blockColorLoad(event);
			DeeznutsBlock.blockColorLoad(event);
		}
	}
}
