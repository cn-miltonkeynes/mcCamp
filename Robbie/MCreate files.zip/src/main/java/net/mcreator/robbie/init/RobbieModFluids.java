
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.robbie.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.robbie.fluid.Texture1Fluid;
import net.mcreator.robbie.fluid.TeFluid;
import net.mcreator.robbie.fluid.BloodofchildrenFluid;
import net.mcreator.robbie.RobbieMod;

public class RobbieModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, RobbieMod.MODID);
	public static final RegistryObject<Fluid> BLOODOFCHILDREN = REGISTRY.register("bloodofchildren", () -> new BloodofchildrenFluid.Source());
	public static final RegistryObject<Fluid> FLOWING_BLOODOFCHILDREN = REGISTRY.register("flowing_bloodofchildren",
			() -> new BloodofchildrenFluid.Flowing());
	public static final RegistryObject<Fluid> TE = REGISTRY.register("te", () -> new TeFluid.Source());
	public static final RegistryObject<Fluid> FLOWING_TE = REGISTRY.register("flowing_te", () -> new TeFluid.Flowing());
	public static final RegistryObject<Fluid> TEXTURE_1 = REGISTRY.register("texture_1", () -> new Texture1Fluid.Source());
	public static final RegistryObject<Fluid> FLOWING_TEXTURE_1 = REGISTRY.register("flowing_texture_1", () -> new Texture1Fluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(BLOODOFCHILDREN.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_BLOODOFCHILDREN.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(TE.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_TE.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(TEXTURE_1.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_TEXTURE_1.get(), renderType -> renderType == RenderType.translucent());
		}
	}
}
