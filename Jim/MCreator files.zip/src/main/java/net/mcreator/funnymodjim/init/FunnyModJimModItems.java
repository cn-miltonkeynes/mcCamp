
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.funnymodjim.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.funnymodjim.item.BeenItem;
import net.mcreator.funnymodjim.item.BakedbenesItem;
import net.mcreator.funnymodjim.item.BakcedarmourItem;
import net.mcreator.funnymodjim.item.BackedhoeItem;
import net.mcreator.funnymodjim.item.BEANZ100Item;
import net.mcreator.funnymodjim.FunnyModJimMod;

public class FunnyModJimModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FunnyModJimMod.MODID);
	public static final RegistryObject<Item> BAKEBENES = block(FunnyModJimModBlocks.BAKEBENES, FunnyModJimModTabs.TAB_BAKEDBENEZ);
	public static final RegistryObject<Item> BAKEBENESBLOCK = block(FunnyModJimModBlocks.BAKEBENESBLOCK, FunnyModJimModTabs.TAB_BAKEDBENEZ);
	public static final RegistryObject<Item> BAKCEDARMOUR_HELMET = REGISTRY.register("bakcedarmour_helmet", () -> new BakcedarmourItem.Helmet());
	public static final RegistryObject<Item> BAKCEDARMOUR_CHESTPLATE = REGISTRY.register("bakcedarmour_chestplate",
			() -> new BakcedarmourItem.Chestplate());
	public static final RegistryObject<Item> BAKCEDARMOUR_LEGGINGS = REGISTRY.register("bakcedarmour_leggings",
			() -> new BakcedarmourItem.Leggings());
	public static final RegistryObject<Item> BAKCEDARMOUR_BOOTS = REGISTRY.register("bakcedarmour_boots", () -> new BakcedarmourItem.Boots());
	public static final RegistryObject<Item> BEEN = REGISTRY.register("been", () -> new BeenItem());
	public static final RegistryObject<Item> BAKEDBENES = REGISTRY.register("bakedbenes", () -> new BakedbenesItem());
	public static final RegistryObject<Item> BEANZ_100 = REGISTRY.register("beanz_100", () -> new BEANZ100Item());
	public static final RegistryObject<Item> BACKEDHOE = REGISTRY.register("backedhoe", () -> new BackedhoeItem());
	public static final RegistryObject<Item> BAKEBENEZ = REGISTRY.register("bakebenez_spawn_egg",
			() -> new ForgeSpawnEggItem(FunnyModJimModEntities.BAKEBENEZ, -39424, -13261,
					new Item.Properties().tab(FunnyModJimModTabs.TAB_BAKEDBENEZ)));
	public static final RegistryObject<Item> BAKEDPIG = REGISTRY.register("bakedpig_spawn_egg",
			() -> new ForgeSpawnEggItem(FunnyModJimModEntities.BAKEDPIG, -13312, -13108,
					new Item.Properties().tab(FunnyModJimModTabs.TAB_BAKEDBENEZ)));

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
