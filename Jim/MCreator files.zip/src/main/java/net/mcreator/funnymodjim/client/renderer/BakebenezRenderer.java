
package net.mcreator.funnymodjim.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.funnymodjim.entity.BakebenezEntity;

public class BakebenezRenderer extends HumanoidMobRenderer<BakebenezEntity, HumanoidModel<BakebenezEntity>> {
	public BakebenezRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
				new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR))));
	}

	@Override
	public ResourceLocation getTextureLocation(BakebenezEntity entity) {
		return new ResourceLocation("funny_mod_jim:textures/c02d78b9411c45786f2388c14886257499f31ea3.png");
	}
}
