
package net.mcreator.funnymodjim.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.PigModel;

import net.mcreator.funnymodjim.entity.BakedpigEntity;

public class BakedpigRenderer extends MobRenderer<BakedpigEntity, PigModel<BakedpigEntity>> {
	public BakedpigRenderer(EntityRendererProvider.Context context) {
		super(context, new PigModel(context.bakeLayer(ModelLayers.PIG)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(BakedpigEntity entity) {
		return new ResourceLocation("funny_mod_jim:textures/pig.png");
	}
}
