
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.funnymodjim.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.funnymodjim.block.BakebenesblockBlock;
import net.mcreator.funnymodjim.block.BakebenesBlock;
import net.mcreator.funnymodjim.FunnyModJimMod;

public class FunnyModJimModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FunnyModJimMod.MODID);
	public static final RegistryObject<Block> BAKEBENES = REGISTRY.register("bakebenes", () -> new BakebenesBlock());
	public static final RegistryObject<Block> BAKEBENESBLOCK = REGISTRY.register("bakebenesblock", () -> new BakebenesblockBlock());
}
