
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.funnymodjim.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.funnymodjim.entity.BakedpigEntity;
import net.mcreator.funnymodjim.entity.BakebenezEntity;
import net.mcreator.funnymodjim.FunnyModJimMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class FunnyModJimModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, FunnyModJimMod.MODID);
	public static final RegistryObject<EntityType<BakebenezEntity>> BAKEBENEZ = register("bakebenez",
			EntityType.Builder.<BakebenezEntity>of(BakebenezEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BakebenezEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<BakedpigEntity>> BAKEDPIG = register("bakedpig",
			EntityType.Builder.<BakedpigEntity>of(BakedpigEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(BakedpigEntity::new).fireImmune().sized(0.9f, 0.9f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			BakebenezEntity.init();
			BakedpigEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BAKEBENEZ.get(), BakebenezEntity.createAttributes().build());
		event.put(BAKEDPIG.get(), BakedpigEntity.createAttributes().build());
	}
}
