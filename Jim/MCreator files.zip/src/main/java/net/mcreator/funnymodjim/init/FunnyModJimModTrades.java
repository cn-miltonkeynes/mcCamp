
/*
*    MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.funnymodjim.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.entity.npc.VillagerProfession;

import java.util.List;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class FunnyModJimModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
		if (event.getType() == VillagerProfession.ARMORER) {
			trades.get(1).add(new BasicItemListing(new ItemStack(FunnyModJimModItems.BEANZ_100.get(), 2),

					new ItemStack(FunnyModJimModItems.BAKCEDARMOUR_LEGGINGS.get()), 10, 5, 0.05f));
			trades.get(1).add(new BasicItemListing(new ItemStack(FunnyModJimModItems.BEANZ_100.get()),

					new ItemStack(FunnyModJimModItems.BAKCEDARMOUR_HELMET.get()), 10, 5, 0.05f));
			trades.get(1).add(new BasicItemListing(new ItemStack(FunnyModJimModItems.BEANZ_100.get(), 4),

					new ItemStack(FunnyModJimModItems.BAKCEDARMOUR_CHESTPLATE.get()), 10, 5, 0.05f));
			trades.get(1).add(new BasicItemListing(new ItemStack(FunnyModJimModItems.BEANZ_100.get()),

					new ItemStack(FunnyModJimModItems.BAKCEDARMOUR_BOOTS.get()), 10, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.TOOLSMITH) {
			trades.get(1).add(new BasicItemListing(new ItemStack(FunnyModJimModItems.BEANZ_100.get(), 6),

					new ItemStack(FunnyModJimModItems.BACKEDHOE.get()), 10, 5, 0.05f));
		}
	}
}
