
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.testing.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.testing.item.SpagettiItem;
import net.mcreator.testing.item.SkylauncherItem;
import net.mcreator.testing.item.RubycrystalItem;
import net.mcreator.testing.item.RubyarmorItem;
import net.mcreator.testing.item.MinezitItem;
import net.mcreator.testing.item.Minecoin200Item;
import net.mcreator.testing.item.Minecoin100Item;
import net.mcreator.testing.item.MinecentItem;
import net.mcreator.testing.item.MinebuckItem;
import net.mcreator.testing.item.MilkItem;
import net.mcreator.testing.item.BananaItem;
import net.mcreator.testing.item.AmethystarmorItem;
import net.mcreator.testing.item.AetherItem;
import net.mcreator.testing.TestingMod;

public class TestingModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TestingMod.MODID);
	public static final RegistryObject<Item> BENORE = block(TestingModBlocks.BENORE, TestingModTabs.TAB_MYMOD);
	public static final RegistryObject<Item> AMETHYSTARMOR_HELMET = REGISTRY.register("amethystarmor_helmet", () -> new AmethystarmorItem.Helmet());
	public static final RegistryObject<Item> AMETHYSTARMOR_CHESTPLATE = REGISTRY.register("amethystarmor_chestplate",
			() -> new AmethystarmorItem.Chestplate());
	public static final RegistryObject<Item> AMETHYSTARMOR_LEGGINGS = REGISTRY.register("amethystarmor_leggings",
			() -> new AmethystarmorItem.Leggings());
	public static final RegistryObject<Item> AMETHYSTARMOR_BOOTS = REGISTRY.register("amethystarmor_boots", () -> new AmethystarmorItem.Boots());
	public static final RegistryObject<Item> RUBYCRYSTAL = REGISTRY.register("rubycrystal", () -> new RubycrystalItem());
	public static final RegistryObject<Item> RUBYARMOR_HELMET = REGISTRY.register("rubyarmor_helmet", () -> new RubyarmorItem.Helmet());
	public static final RegistryObject<Item> RUBYARMOR_CHESTPLATE = REGISTRY.register("rubyarmor_chestplate", () -> new RubyarmorItem.Chestplate());
	public static final RegistryObject<Item> RUBYARMOR_LEGGINGS = REGISTRY.register("rubyarmor_leggings", () -> new RubyarmorItem.Leggings());
	public static final RegistryObject<Item> RUBYARMOR_BOOTS = REGISTRY.register("rubyarmor_boots", () -> new RubyarmorItem.Boots());
	public static final RegistryObject<Item> MILK_BUCKET = REGISTRY.register("milk_bucket", () -> new MilkItem());
	public static final RegistryObject<Item> SPAGETTI = REGISTRY.register("spagetti", () -> new SpagettiItem());
	public static final RegistryObject<Item> MINECOIN_100 = REGISTRY.register("minecoin_100", () -> new Minecoin100Item());
	public static final RegistryObject<Item> MINECOIN_200 = REGISTRY.register("minecoin_200", () -> new Minecoin200Item());
	public static final RegistryObject<Item> MINECENT = REGISTRY.register("minecent", () -> new MinecentItem());
	public static final RegistryObject<Item> MINEZIT = REGISTRY.register("minezit", () -> new MinezitItem());
	public static final RegistryObject<Item> MINEBUCK = REGISTRY.register("minebuck", () -> new MinebuckItem());
	public static final RegistryObject<Item> ALEX = REGISTRY.register("alex_spawn_egg",
			() -> new ForgeSpawnEggItem(TestingModEntities.ALEX, -13210, -1, new Item.Properties().tab(TestingModTabs.TAB_MYMOD)));
	public static final RegistryObject<Item> AETHER = REGISTRY.register("aether", () -> new AetherItem());
	public static final RegistryObject<Item> BANANA = REGISTRY.register("banana", () -> new BananaItem());
	public static final RegistryObject<Item> SKYLAUNCHER = REGISTRY.register("skylauncher", () -> new SkylauncherItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
