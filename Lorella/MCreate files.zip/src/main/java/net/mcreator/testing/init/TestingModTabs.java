
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.testing.init;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class TestingModTabs {
	public static CreativeModeTab TAB_CURRANCY;
	public static CreativeModeTab TAB_MYMOD;

	public static void load() {
		TAB_CURRANCY = new CreativeModeTab("tabcurrancy") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TestingModItems.MINECOIN_100.get());
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
		TAB_MYMOD = new CreativeModeTab("tabmymod") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TestingModBlocks.BENORE.get());
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
	}
}
