
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.testing.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.testing.block.MilkBlock;
import net.mcreator.testing.block.BenoreBlock;
import net.mcreator.testing.block.AetherPortalBlock;
import net.mcreator.testing.TestingMod;

public class TestingModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, TestingMod.MODID);
	public static final RegistryObject<Block> BENORE = REGISTRY.register("benore", () -> new BenoreBlock());
	public static final RegistryObject<Block> MILK = REGISTRY.register("milk", () -> new MilkBlock());
	public static final RegistryObject<Block> AETHER_PORTAL = REGISTRY.register("aether_portal", () -> new AetherPortalBlock());
}
