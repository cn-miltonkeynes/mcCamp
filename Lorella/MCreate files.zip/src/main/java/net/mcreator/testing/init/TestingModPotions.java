
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.testing.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.testing.TestingMod;

public class TestingModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, TestingMod.MODID);
	public static final RegistryObject<Potion> SHARING = REGISTRY.register("sharing",
			() -> new Potion(new MobEffectInstance(MobEffects.HARM, 3600, 0, false, true)));
}
