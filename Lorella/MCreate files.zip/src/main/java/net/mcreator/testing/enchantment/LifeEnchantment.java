
package net.mcreator.testing.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;

public class LifeEnchantment extends Enchantment {
	public LifeEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.RARE, EnchantmentCategory.ARMOR_CHEST, slots);
	}

	@Override
	public int getMinLevel() {
		return 5;
	}

	@Override
	public int getMaxLevel() {
		return 20;
	}
}
