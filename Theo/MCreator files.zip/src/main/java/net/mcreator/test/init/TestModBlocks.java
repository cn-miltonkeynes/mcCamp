
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.test.block.EnderwoodBlock;
import net.mcreator.test.block.EnderleBlock;
import net.mcreator.test.block.EnderiteoreBlock;
import net.mcreator.test.block.BlockofenderiteBlock;
import net.mcreator.test.block.AcidBlock;
import net.mcreator.test.TestMod;

public class TestModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, TestMod.MODID);
	public static final RegistryObject<Block> ENDERITEORE = REGISTRY.register("enderiteore", () -> new EnderiteoreBlock());
	public static final RegistryObject<Block> BLOCKOFENDERITE = REGISTRY.register("blockofenderite", () -> new BlockofenderiteBlock());
	public static final RegistryObject<Block> ACID = REGISTRY.register("acid", () -> new AcidBlock());
	public static final RegistryObject<Block> ENDERWOOD = REGISTRY.register("enderwood", () -> new EnderwoodBlock());
	public static final RegistryObject<Block> ENDERLE = REGISTRY.register("enderle", () -> new EnderleBlock());
}
