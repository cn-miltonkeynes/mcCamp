
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.test.entity.NethertminionEntity;
import net.mcreator.test.entity.InterdimentionallylostEntity;
import net.mcreator.test.entity.EnderminionEntity;
import net.mcreator.test.entity.EndercannonEntity;
import net.mcreator.test.TestMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TestModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, TestMod.MODID);
	public static final RegistryObject<EntityType<InterdimentionallylostEntity>> INTERDIMENTIONALLYLOST = register(
			"projectile_interdimentionallylost",
			EntityType.Builder.<InterdimentionallylostEntity>of(InterdimentionallylostEntity::new, MobCategory.MISC)
					.setCustomClientFactory(InterdimentionallylostEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<EnderminionEntity>> ENDERMINION = register("enderminion",
			EntityType.Builder.<EnderminionEntity>of(EnderminionEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EnderminionEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<NethertminionEntity>> NETHERTMINION = register("nethertminion",
			EntityType.Builder.<NethertminionEntity>of(NethertminionEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(NethertminionEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EndercannonEntity>> ENDERCANNON = register("projectile_endercannon",
			EntityType.Builder.<EndercannonEntity>of(EndercannonEntity::new, MobCategory.MISC).setCustomClientFactory(EndercannonEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			EnderminionEntity.init();
			NethertminionEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(ENDERMINION.get(), EnderminionEntity.createAttributes().build());
		event.put(NETHERTMINION.get(), NethertminionEntity.createAttributes().build());
	}
}
