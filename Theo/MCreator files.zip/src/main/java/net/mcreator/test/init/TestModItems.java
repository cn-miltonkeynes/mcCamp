
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.test.item.TearedsouloftheendItem;
import net.mcreator.test.item.InterdimentionallylostItem;
import net.mcreator.test.item.EnderiteswordItem;
import net.mcreator.test.item.EnderiteshovelItem;
import net.mcreator.test.item.EnderiteshardsItem;
import net.mcreator.test.item.EnderitepickaxeItem;
import net.mcreator.test.item.EnderitehoeItem;
import net.mcreator.test.item.EnderiteaxeItem;
import net.mcreator.test.item.EnderitearmourItem;
import net.mcreator.test.item.EnderiteItem;
import net.mcreator.test.item.EnderfruitItem;
import net.mcreator.test.item.EndercannonItem;
import net.mcreator.test.item.EnderarrowItem;
import net.mcreator.test.item.AcidItem;
import net.mcreator.test.TestMod;

public class TestModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TestMod.MODID);
	public static final RegistryObject<Item> ENDERITEORE = block(TestModBlocks.ENDERITEORE, TestModTabs.TAB_ENDUPDATE);
	public static final RegistryObject<Item> ENDERITEARMOUR_HELMET = REGISTRY.register("enderitearmour_helmet",
			() -> new EnderitearmourItem.Helmet());
	public static final RegistryObject<Item> ENDERITEARMOUR_CHESTPLATE = REGISTRY.register("enderitearmour_chestplate",
			() -> new EnderitearmourItem.Chestplate());
	public static final RegistryObject<Item> ENDERITEARMOUR_LEGGINGS = REGISTRY.register("enderitearmour_leggings",
			() -> new EnderitearmourItem.Leggings());
	public static final RegistryObject<Item> ENDERITEARMOUR_BOOTS = REGISTRY.register("enderitearmour_boots", () -> new EnderitearmourItem.Boots());
	public static final RegistryObject<Item> ENDERITE = REGISTRY.register("enderite", () -> new EnderiteItem());
	public static final RegistryObject<Item> ENDERITESHARDS = REGISTRY.register("enderiteshards", () -> new EnderiteshardsItem());
	public static final RegistryObject<Item> ENDERITESWORD = REGISTRY.register("enderitesword", () -> new EnderiteswordItem());
	public static final RegistryObject<Item> BLOCKOFENDERITE = block(TestModBlocks.BLOCKOFENDERITE, TestModTabs.TAB_ENDUPDATE);
	public static final RegistryObject<Item> ENDERARROW = REGISTRY.register("enderarrow", () -> new EnderarrowItem());
	public static final RegistryObject<Item> INTERDIMENTIONALLYLOST = REGISTRY.register("interdimentionallylost",
			() -> new InterdimentionallylostItem());
	public static final RegistryObject<Item> ACID_BUCKET = REGISTRY.register("acid_bucket", () -> new AcidItem());
	public static final RegistryObject<Item> ENDERWOOD = block(TestModBlocks.ENDERWOOD, TestModTabs.TAB_ENDUPDATE);
	public static final RegistryObject<Item> ENDERLE = block(TestModBlocks.ENDERLE, TestModTabs.TAB_ENDUPDATE);
	public static final RegistryObject<Item> ENDERMINION = REGISTRY.register("enderminion_spawn_egg",
			() -> new ForgeSpawnEggItem(TestModEntities.ENDERMINION, -6750055, -10092442, new Item.Properties().tab(TestModTabs.TAB_ENDUPDATE)));
	public static final RegistryObject<Item> TEAREDSOULOFTHEEND = REGISTRY.register("tearedsouloftheend", () -> new TearedsouloftheendItem());
	public static final RegistryObject<Item> NETHERTMINION = REGISTRY.register("nethertminion_spawn_egg",
			() -> new ForgeSpawnEggItem(TestModEntities.NETHERTMINION, -6750208, -10092544, new Item.Properties().tab(TestModTabs.TAB_ENDUPDATE)));
	public static final RegistryObject<Item> ENDERFRUIT = REGISTRY.register("enderfruit", () -> new EnderfruitItem());
	public static final RegistryObject<Item> ENDERCANNON = REGISTRY.register("endercannon", () -> new EndercannonItem());
	public static final RegistryObject<Item> ENDERITEAXE = REGISTRY.register("enderiteaxe", () -> new EnderiteaxeItem());
	public static final RegistryObject<Item> ENDERITEPICKAXE = REGISTRY.register("enderitepickaxe", () -> new EnderitepickaxeItem());
	public static final RegistryObject<Item> ENDERITESHOVEL = REGISTRY.register("enderiteshovel", () -> new EnderiteshovelItem());
	public static final RegistryObject<Item> ENDERITEHOE = REGISTRY.register("enderitehoe", () -> new EnderitehoeItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
