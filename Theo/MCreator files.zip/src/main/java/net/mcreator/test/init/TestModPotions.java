
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.test.TestMod;

public class TestModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, TestMod.MODID);
	public static final RegistryObject<Potion> GODPOT = REGISTRY.register("godpot", () -> new Potion(
			new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 3600, 0, false, true), new MobEffectInstance(MobEffects.DIG_SPEED, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3600, 0, false, true), new MobEffectInstance(MobEffects.HEAL, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.HARM, 3600, 0, false, true), new MobEffectInstance(MobEffects.REGENERATION, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.INVISIBILITY, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.WATER_BREATHING, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.NIGHT_VISION, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.HEALTH_BOOST, 3600, 0, false, true), new MobEffectInstance(MobEffects.ABSORPTION, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.SATURATION, 3600, 0, false, true), new MobEffectInstance(MobEffects.GLOWING, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.LUCK, 3600, 0, false, true), new MobEffectInstance(MobEffects.SLOW_FALLING, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.CONDUIT_POWER, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.HERO_OF_THE_VILLAGE, 3600, 0, false, true)));
}
